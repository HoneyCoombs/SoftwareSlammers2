module.exports = { 
    computeExam: function(a) { return (0.4) * a }
};