module.exports = { 
    computeHW: function(a,b,c) { return (0.2) * ((a + b + c)/3) }
};